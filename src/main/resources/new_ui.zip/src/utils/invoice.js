const Invoice = ()=>{

    const invoice={
        from: {
            name:"", 
            phone:"", 
            address:""
        },
        to: {
            name:"", 
            phone:"", 
            address:""
        },
        headers:{

        },
        dataList: [],
        subtotal:'',
        discounts: '',
        tex:"",
        total:''
    }



    return (
        <
    )
}