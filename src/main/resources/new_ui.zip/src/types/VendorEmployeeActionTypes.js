export const GET_ALL_VENDOR_EMPLOYEE_LIST_SUCCESS = 'get_all_vendor_employee_list_success';

export const VENDOR_EMPLOYEE_ADD_SUCCESS = 'vendor_employee_add_success';

export const SHOW_VENDOR_EMPLOYEE_LOADER = 'show_vendor_employee_loader';

export const REMOVE_VENDOR_EMPLOYEE_LOADER = 'remove_vendor_employee_loader';

export const VENDOR_EMPLOYEE_TO_EDIT = 'vendor_employee_to_edit';

export const VENDOR_EMPLOYEE_EDIT_SUCCESS = 'vendor_employee_edit_success';

export const GET_FINISHING_VENDOR_EMPLOYEE_LIST = 'get_finishing_vendor_employee_list';

export const VENDOR_EMPLOYEE_DELETE_SUCCESS= 'vendor_employee_delete_success';