// MENU GROUPS
export const GET_MENU_GROUP_LIST_SUCCESS="get_menu_group_list_success";
export const GET_MENU_GROUP_LIST_FAIL="get_menu_group_list_fail";

export const GET_MENU_GROUP_SUCCESS="get_menu_group_success";
export const GET_MENU_GROUP_FAIL="get_menu_group_fail";

export const ADD_MENU_GROUP_SUCCESS="add_menu_group_success";
export const ADD_MENU_GROUP_FAIL="add_menu_group_fail";

export const UPDATE_MENU_GROUP_SUCCESS="update_menu_group_success";
export const UPDATE_MENU_GROUP_FAIL="update_menu_group_fail";

export const DELETE_MENU_GROUP_SUCCESS="delete_menu_group_success";
export const DELETE_MENU_GROUP_FAIL="delete_menu_group_fail";

// MENU ITEMS
export const GET_MENU_ITEM_LIST_SUCCESS="get_menu_item_list_success";
export const GET_MENU_ITEM_LIST_FAIL="get_menu_item_list_fail";

export const GET_MENU_ITEM_SUCCESS="get_menu_group_success";
export const GET_MENU_ITEM_FAIL="get_menu_group_fail";

export const ADD_MENU_ITEM_SUCCESS="add_menu_item_success";
export const ADD_MENU_ITEM_FAIL="add_menu_item_fail";

export const UPDATE_MENU_ITEM_SUCCESS="update_menu_item_success";
export const UPDATE_MENU_ITEM_FAIL="update_menu_item_fail";

export const DELETE_MENU_ITEM_SUCCESS="delete_menu_item_success";
export const DELETE_MENU_ITEM_FAIL="delete_menu_item_fail";

// ROLE MENU GROUPS
export const GET_ROLE_MENU_GROUP_LIST_SUCCESS="get_role_menu_group_list_success";
export const GET_ROLE_MENU_GROUP_LIST_FAIL="get_role_menu_group_list_fail";

export const GET_ROLE_MENU_GROUP_SUCCESS="get_role_menu_group_success";
export const GET_ROLE_MENU_GROUP_FAIL="get_role_menu_group_fail";

export const ADD_ROLE_MENU_GROUP_SUCCESS="add_role_menu_group_success";
export const ADD_ROLE_MENU_GROUP_FAIL="add_role_menu_group_fail";

export const UPDATE_ROLE_MENU_GROUP_SUCCESS="update_role_menu_group_success";
export const UPDATE_ROLE_MENU_GROUP_FAIL="update_role_menu_group_fail";

export const DELETE_ROLE_MENU_GROUP_SUCCESS="delete_role_menu_group_success";
export const DELETE_ROLE_MENU_GROUP_FAIL="delete_role_menu_group_fail";

// ROLE MENU ITEMS
export const GET_ROLE_MENU_ITEM_LIST_SUCCESS="get_role_menu_item_list_success";
export const GET_ROLE_MENU_ITEM_LIST_FAIL="get_role_menu_item_list_fail";

export const GET_ROLE_MENU_ITEM_SUCCESS="get_role_menu_group_success";
export const GET_ROLE_MENU_ITEM_FAIL="get_role_menu_group_fail";

export const ADD_ROLE_MENU_ITEM_SUCCESS="add_role_menu_item_success";
export const ADD_ROLE_MENU_ITEM_FAIL="add_role_menu_item_fail";

export const UPDATE_ROLE_MENU_ITEM_SUCCESS="update_role_menu_item_success";
export const UPDATE_ROLE_MENU_ITEM_FAIL="update_role_menu_item_fail";

export const DELETE_ROLE_MENU_ITEM_SUCCESS="delete_role_menu_item_success";
export const DELETE_ROLE_MENU_ITEM_FAIL="delete_role_menu_item_fail";


export const GET_USER_MENU_GROUP_LIST_SUCCESS="get_user_menu_group_list_success";
export const GET_USER_MENU_GROUP_LIST_FAIL="get_user_menu_group_list_fail";

