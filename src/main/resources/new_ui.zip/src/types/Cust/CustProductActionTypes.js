export const GET_ALL_CUST_PRODUCTS_SUCCESS = 'get_all_cust_products_success';

export const CUST_PRODUCT_ADD_SUCCESS = 'cust_product_add_success';

export const SHOW_CUST_PRODUCT_LOADER = 'show_cust_product_loader';

export const REMOVE_CUST_PRODUCT_LOADER = 'remove_cust_product_loader';

export const CUST_PRODUCT_TO_EDIT = 'cust_product_to_edit';

export const CUST_PRODUCT_TO_DELETE = 'cust_product_to_delete';

export const CUST_PRODUCT_EDIT_SUCCESS = 'cust_product_edit_success';

export const CUST_PRODUCT_DELETE_SUCCESS = 'cust_product_delete_success';

export const GET_FINISHING_CUST_PRODUCTS = 'get_finishing_cust_products';