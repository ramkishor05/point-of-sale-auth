export const GET_ALL_SALES_SUCCESS = 'get_all_sales';

export const GET_SALES_TODAY_SUCCESS = 'get_sales_today_success';

export const GET_SALES_YESTERDAY_SUCCESS = 'get_sales_yesterday_success';

export const GET_SALES_LONG_SUCCESS = 'get_sales_long_success';

export const SALE_TO_EDIT = 'sale_to_edit';




