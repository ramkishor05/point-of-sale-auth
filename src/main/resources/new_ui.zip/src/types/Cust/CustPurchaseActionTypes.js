export const GET_ALL_PURCHASES_SUCCESS = 'get_all_purchases';

export const GET_ALL_PURCHASES_SUPPLIER_SUCCESS = 'get_all_purchases_by_supplier';

export const GET_PURCHASES_TODAY_SUCCESS = 'get_purchases_today_success';

export const GET_PURCHASES_YESTERDAY_SUCCESS = 'get_purchases_yesterday_success';

export const GET_PURCHASES_LONG_SUCCESS = 'get_purchases_long_success';

export const PURCHASE_TO_EDIT = 'purchase_to_edit';