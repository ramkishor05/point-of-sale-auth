export const GET_ALL_CUST_CATEGERY_SUCCESS = 'get_all_cust_category_success';
export const GET_ALL_CUST_CATEGERY_FAIL = 'get_all_cust_category_fail';

export const GET_CUST_CATEGERY_TODAY_SUCCESS = 'get_cust_category_today_success';
export const GET_CUST_CATEGERY_YESTERDAY_SUCCESS = 'get_cust_category_yesterday_success';
export const GET_CUST_CATEGERY_LONG_SUCCESS = 'get_cust_category_long_success';

export const ADD_CUST_CATEGERY_SUCCESS = 'add_cust_category_success';
export const ADD_CUST_CATEGERY_FAIL = 'add_cust_category_fail';

export const EDIT_CUST_CATEGERY_SUCCESS = 'edit_cust_category_success';
export const EDIT_CUST_CATEGERY_FAIL = 'edit_cust_category_fail';

export const DELETE_CUST_CATEGERY_SUCCESS = 'delete_cust_category_success';
export const DELETE_CUST_CATEGERY_FAIL = 'delete_cust_category_fail';

export const RENDER_CUST_CATEGERY_TO_EDIT = 'render_cust_category_to_edit';

export const SHOW_CUST_CATEGERY_LOADER = 'show_cust_category_loader';

export const REMOVE_CUST_CATEGERY_LOADER = 'remove_cust_category_loader';