export const GET_ALL_DASHBOARDS_SUCCESS = 'get_all_dashboards';

export const GET_DASHBOARDS_TODAY_SUCCESS = 'get_dashboards_today_success';

export const GET_DASHBOARDS_YESTERDAY_SUCCESS = 'get_dashboards_yesterday_success';

export const GET_DASHBOARDS_LONG_SUCCESS = 'get_dashboards_long_success';

export const DASHBOARD_TO_EDIT = 'dashboard_to_edit';




