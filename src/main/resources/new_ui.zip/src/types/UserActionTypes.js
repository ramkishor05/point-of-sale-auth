export const GET_USERS_SUCCESS = 'get_users_success';

export const GET_USER_SUCCESS = 'get_user_success';

export const GET_USER_FAIL = 'get_user_fail';


export const USER_UPDATE_SUCCESS = 'user_update_success';

export const USER_UPDATE_FAIL = 'user_update_fail';

export const OPEN_ADD_USER_MODAL = 'open_add_user_modal';

export const OPEN_EDIT_USER_MODAL = 'open_edit_user_modal';

export const OPEN_DELETE_USER_MODAL = 'open_delete_user_modal';

export const USER_UPDATE_PROFILE_SUCCESS = 'user_update_profile_success';

export const USER_UPDATE_PROFILE_FAIL = 'user_update_profile_fail';

export const GET_USER_PROFILE_SUCCESS ='get_user_profile_success';

export const GET_USER_PROFILE_FAIL='get_user_profile_fail';

export const USER_TO_EDIT = 'user_to_edit';

