export const SHOW_LOADER = 'show_loader';

export const REMOVE_LOADER = 'remove_loader';