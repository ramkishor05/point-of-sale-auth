export const GET_ALL_VENDOR_USER_LIST_SUCCESS = 'get_all_vendor_user_list_success';

export const VENDOR_USER_ADD_SUCCESS = 'vendor_user_add_success';

export const SHOW_VENDOR_USER_LOADER = 'show_vendor_user_loader';

export const REMOVE_VENDOR_USER_LOADER = 'remove_vendor_user_loader';

export const VENDOR_USER_TO_EDIT = 'vendor_user_to_edit';

export const VENDOR_USER_EDIT_SUCCESS = 'vendor_user_edit_success';

export const GET_FINISHING_VENDOR_USER_LIST = 'get_finishing_vendor_user_list';

export const VENDOR_USER_DELETE_SUCCESS= 'vendor_user_delete_success';