export const GET_ALL_VENDOR_SUPPLIER_LIST_SUCCESS = 'get_all_vendor_supplier_list_success';

export const VENDOR_SUPPLIER_ADD_SUCCESS = 'vendor_supplier_add_success';

export const SHOW_VENDOR_SUPPLIER_LOADER = 'show_vendor_supplier_loader';

export const REMOVE_VENDOR_SUPPLIER_LOADER = 'remove_vendor_supplier_loader';

export const VENDOR_SUPPLIER_TO_EDIT = 'vendor_supplier_to_edit';

export const VENDOR_SUPPLIER_EDIT_SUCCESS = 'vendor_supplier_edit_success';

export const GET_FINISHING_VENDOR_SUPPLIER_LIST = 'get_finishing_vendor_supplier_list';

export const VENDOR_SUPPLIER_DELETE_SUCCESS= 'vendor_supplier_delete_success';