export const GET_ALL_GLOBAL_CATEGERY_SUCCESS = 'get_all_global_category_success';
export const GET_ALL_GLOBAL_CATEGERY_FAIL = 'get_all_global_category_fail';

export const GET_GLOBAL_CATEGERY_TODAY_SUCCESS = 'get_global_category_today_success';
export const GET_GLOBAL_CATEGERY_YESTERDAY_SUCCESS = 'get_global_category_yesterday_success';
export const GET_GLOBAL_CATEGERY_LONG_SUCCESS = 'get_global_category_long_success';

export const ADD_GLOBAL_CATEGERY_SUCCESS = 'add_global_category_success';
export const ADD_GLOBAL_CATEGERY_FAIL = 'add_global_category_fail';

export const EDIT_GLOBAL_CATEGERY_SUCCESS = 'edit_global_category_success';
export const EDIT_GLOBAL_CATEGERY_FAIL = 'edit_global_category_fail';

export const DELETE_GLOBAL_CATEGERY_SUCCESS = 'delete_global_category_success';
export const DELETE_GLOBAL_CATEGERY_FAIL = 'delete_global_category_fail';

export const RENDER_GLOBAL_CATEGERY_TO_EDIT = 'render_global_category_to_edit';

export const SHOW_GLOBAL_CATEGERY_LOADER = 'show_global_category_loader';
export const REMOVE_GLOBAL_CATEGERY_LOADER = 'remove_global_category_loader';