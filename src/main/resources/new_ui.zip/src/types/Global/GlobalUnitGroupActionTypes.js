export const GET_ALL_GLOBAL_UNIT_GROUPS_SUCCESS = 'get_all_global_unit_groups_success';
export const GET_ALL_GLOBAL_UNIT_GROUPS_FAIL = 'get_all_global_unit_groups_fail';


export const GET_GLOBAL_UNIT_GROUPS_TODAY_SUCCESS = 'get_global_unit_groups_today_success';
export const GET_GLOBAL_UNIT_GROUPS_TODAY_FAIL = 'get_global_unit_groups_today_fail';


export const GET_GLOBAL_UNIT_GROUPS_YESTERDAY_SUCCESS = 'get_global_unit_groups_yesterday_success';
export const GET_GLOBAL_UNIT_GROUPS_YESTERDAY_FAIL = 'get_global_unit_groups_yesterday_fail';

export const GET_GLOBAL_UNIT_GROUPS_LONG_SUCCESS = 'get_global_unit_groups_long_success';

export const ADD_GLOBAL_UNIT_GROUP_SUCCESS = 'add_global_unit_group_success';
export const ADD_GLOBAL_UNIT_GROUP_FAIL = 'add_global_unit_group_fail';


export const EDIT_GLOBAL_UNIT_GROUP_SUCCESS = 'edit_global_unit_group_success';
export const EDIT_GLOBAL_UNIT_GROUP_FAIL = 'edit_global_unit_group_fail';


export const DELETE_GLOBAL_UNIT_GROUP_SUCCESS = 'delete_global_unit_group_success';
export const DELETE_GLOBAL_UNIT_GROUP_FAIL = 'delete_global_unit_group_fail';

export const RENDER_GLOBAL_UNIT_GROUP_TO_EDIT = 'render_global_unit_group_to_edit';
