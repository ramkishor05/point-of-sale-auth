export const GET_ALL_GLOBAL_UNITS_SUCCESS = 'get_all_global_units_success';
export const GET_ALL_GLOBAL_UNITS_FAIL = 'get_all_global_units_fail';


export const GET_GLOBAL_UNITS_TODAY_SUCCESS = 'get_global_units_today_success';
export const GET_GLOBAL_UNITS_TODAY_FAIL = 'get_global_units_today_fail';


export const GET_GLOBAL_UNITS_YESTERDAY_SUCCESS = 'get_global_units_yesterday_success';
export const GET_GLOBAL_UNITS_YESTERDAY_FAIL = 'get_global_units_yesterday_fail';

export const GET_GLOBAL_UNITS_LONG_SUCCESS = 'get_global_units_long_success';

export const ADD_GLOBAL_UNIT_SUCCESS = 'add_global_unit_success';
export const ADD_GLOBAL_UNIT_FAIL = 'add_global_unit_fail';


export const EDIT_GLOBAL_UNIT_SUCCESS = 'edit_global_unit_success';
export const EDIT_GLOBAL_UNIT_FAIL = 'edit_global_unit_fail';


export const DELETE_GLOBAL_UNIT_SUCCESS = 'delete_global_unit_success';
export const DELETE_GLOBAL_UNIT_FAIL = 'delete_global_unit_fail';

export const RENDER_GLOBAL_UNIT_TO_EDIT = 'render_global_unit_to_edit';
