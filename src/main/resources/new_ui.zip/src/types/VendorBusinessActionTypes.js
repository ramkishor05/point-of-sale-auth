export const GET_ALL_VENDOR_BUSINESS_LIST_SUCCESS = 'get_all_vendor_business_list_success';

export const VENDOR_BUSINESS_ADD_SUCCESS = 'vendor_business_add_success';

export const SHOW_VENDOR_BUSINESS_LOADER = 'show_vendor_business_loader';

export const REMOVE_VENDOR_BUSINESS_LOADER = 'remove_vendor_business_loader';

export const VENDOR_BUSINESS_TO_EDIT = 'vendor_business_to_edit';

export const VENDOR_BUSINESS_EDIT_SUCCESS = 'vendor_business_edit_success';

export const GET_FINISHING_VENDOR_BUSINESS_LIST = 'get_finishing_vendor_business_list';