export const GET_USER_ROLES_SUCCESS = 'get_user_roles_success';

export const GET_USER_ROLE_SUCCESS = 'get_user_role_success';

export const USER_ROLE_UPDATE_SUCCESS = 'user_role_update_success';

export const USER_ROLE_UPDATE_FAIL = 'user_role_update_fail';

export const OPEN_ADD_USER_ROLE_MODAL = 'open_add_user_role_modal';

export const OPEN_EDIT_USER_ROLE_MODAL = 'open_edit_user_role_modal';

export const OPEN_DELETE_USER_ROLE_MODAL = 'open_delete_user_role_modal';

export const USER_ROLE_UPDATE_PROFILE_SUCCESS = 'user_role_update_profile_success';

export const USER_ROLE_UPDATE_PROFILE_FAIL = 'user_role_update_profile_fail';

export const GET_USER_ROLE_PROFILE_SUCCESS ='get_user_role_profile_success';

export const GET_USER_ROLE_PROFILE_FAIL='get_user_role_profile_fail';

export const USER_ROLE_TO_EDIT = 'user_role_to_edit';

