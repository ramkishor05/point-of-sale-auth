export const GET_ALL_VENDOR_CUSTOMER_LIST_SUCCESS = 'get_all_vendor_customer_list_success';

export const VENDOR_CUSTOMER_ADD_SUCCESS = 'vendor_customer_add_success';

export const SHOW_VENDOR_CUSTOMER_LOADER = 'show_vendor_customer_loader';

export const REMOVE_VENDOR_CUSTOMER_LOADER = 'remove_vendor_customer_loader';

export const VENDOR_CUSTOMER_TO_EDIT = 'vendor_customer_to_edit';

export const VENDOR_CUSTOMER_EDIT_SUCCESS = 'vendor_customer_edit_success';

export const GET_FINISHING_VENDOR_CUSTOMER_LIST = 'get_finishing_vendor_customer_list';

export const VENDOR_CUSTOMER_DELETE_SUCCESS= 'vendor_customer_delete_success';